package com.farmcard.farmcard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FarmcardApplicationTests {

	@Test
	void contextLoads() {
	}

}
